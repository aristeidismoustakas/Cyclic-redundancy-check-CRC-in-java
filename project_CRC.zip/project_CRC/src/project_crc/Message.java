/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_crc;

/**
 *
 * @author Aristidis Moustakas  
 */
public class Message {
    private int[] array;
    private boolean isCorrect;
    public Message(int [] ar,boolean cor)
       {
                array=ar;
                isCorrect=cor;
       }

    /**
     * @return the array
     */
    public int[] getArray() {
        return array;
    }

    /**
     * @param array the array to set
     */
    public void setArray(int[] array) {
        this.array = array;
    }

    /**
     * @return the correct
     */
    public boolean getIsCorrect() {
        return isCorrect;
    }

    /**
     * @param correct the correct to set
     */
    public void setIsCorrect(boolean correct) {
        this.isCorrect= correct;
    }
    
}
