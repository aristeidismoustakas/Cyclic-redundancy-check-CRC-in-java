/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_crc;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author Aristidis Moustakas 
 */
public class Transmitter {
    
   public Transmitter()
   {}
   
   public Message sendMessage(int num,int P[],int ber)
   {
       int i;
       Random r=new Random();
        int[]array=new int[num];
       for(i=0;i<num-P.length+1;i++)
       {
           array[i]=r.nextInt(2);
       }
       for(i=num-P.length+1;i<num;i++)
       {
           array[i]=0;
       }
        int [] x=new int[array.length];
         for(i=0;i<array.length;i++)
        {
            x[i]=array[i];
        }
       
        
       modulo(array,x, P);
       Message mes=distortion(array,ber);
       return mes;
   }

     public int [] modulo(int [] a,int[] x,int[] b )
    {
       int el=0;
        for(int i=0;(i<=x.length-b.length);i++)
        {
            if(x[i]!=0)
            {
                for(int j=i;j<i+b.length;j++)
                {
                   x[j]=mod(x[j],b[j-i]);
                }
            }
        }
        for(int i=x.length-b.length+1;i<x.length;i++)
        {
            a[i]=x[i];
        }
        return a;
    }
    
    public int mod(int a,int b)
    {
        if(a==b)
            return 0;
        return 1;
    }

    
   public Message distortion(int [] array,int ber)
    {boolean isCorr=true;
        int w;
        Message mes;
        Random r=new Random();
        for(int i=0;i<array.length;i++)
        {
            
        int k=r.nextInt(ber);
        if(k==0)
         {
            if(array[i]==0)
                array[i]=1;
            else
                array[i]=0;
            isCorr=false;
          }
        }
        mes=new Message(array, isCorr);
        return mes;
        
    }
   
   
   

    
}
