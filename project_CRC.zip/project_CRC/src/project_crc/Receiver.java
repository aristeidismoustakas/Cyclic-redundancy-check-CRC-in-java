/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_crc;

import java.util.Arrays;

/**
 *
 * @author Aristidis Moustakas 
 */
public class Receiver {
    public Receiver()
    {
        
    }
    
    
    public boolean getMessage(Message message,int p[])
    {
        int[] k=message.getArray();
        boolean a=modulo(k, p);
        return a;
        
    }

     public boolean modulo(int [] x,int [] b)
    {
        for(int i=0;(i<=x.length-b.length);i++)
        {
            if(x[i]!=0)
            {
                for(int j=i;j<i+b.length;j++)
                {
                   x[j]=mod(x[j],b[j-i]);

                }
            }
        }
        
       return isCorrect(x);
    }
    public int mod(int a,int b)
    {
        if(a==b)
            return 0;
        return 1;
    }
    
    public boolean isCorrect(int []x)
    {
        for(int i=0;i<x.length;i++)
        {
            if(x[i]==1)
            { 
                return false;
            }
        }
        return true;
    }
}
