/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_crc;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Aristidis Moustakas 
 */
public class Project_CRC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Transmitter sender=new Transmitter();
        Receiver receiver=new Receiver();
        int messagesWithError=0;
        int messagesWithErrorWhoAreFound=0;
        int messagesWithErrorWhoAreNOTFound=0;
        Message mes;
        boolean isCorrect;
        boolean findError;
        System.out.println("1. Run an example with your arguments.");
        System.out.println("2. Run an example with number of messages=1000000, Pattern={1,1,0,1,0,1}, size of every message=10 and ber=1/1000");
        System.out.println("Please choose 1 or 2");
        boolean flag=true;
        int num=0;
        int numOfBits=0;
        Scanner s=new Scanner(System.in);
        int a = 0;
        int[] P=new int[6];
        int ber=0;
        while(flag)
        {
            flag=false;
            try {
                a=s.nextInt();              
            } catch (Exception e) {
                
                System.out.println("Please choose the first or second choice");
                s.nextLine();
                flag=true;
            }
            if((!flag)&&((a!=1)&&(a!=2)))
            {
                System.out.println("Please choose the first or second choice");
                flag=true;
            }
        }
        if(a==1)
        {   System.out.println("Please give the number of messages.");
            flag=true;
            while(flag)
            {
                flag=false;
                try {
                    num=s.nextInt();              
                } catch (Exception e) {

                    System.out.println("Please give a positive number");
                    s.nextLine();
                    flag=true;
                }
                if((!flag)&&(num<0))
                {
                    System.out.println("Please give a positive number");
                    flag=true;
                }
            }

             System.out.println("Please give the size of each message in bits.");
            flag=true;
            while(flag)
            {
                flag=false;
                try {
                    numOfBits=s.nextInt();              
                } catch (Exception e) {

                    System.out.println("Please give a positive number.");
                    s.nextLine();
                    flag=true;
                }
                if((!flag)&&(num<=0))
                {
                    System.out.println("Please give a positive number.");
                    flag=true;
                }
            }
            flag=true;
            System.out.println("Please give the bit error rate(e.x. if you want 1 in 500 give 500).");
            while(flag)
            {
                flag=false;
                try {
                    ber=s.nextInt();              
                } catch (Exception e) {

                    System.out.println("Please give the bit error rate(e.x. if you want 1 in 500 give 500).");
                    s.nextLine();
                    flag=true;
                }
                if((!flag)&&(num<=1))
                {
                    System.out.println("Please give a positive number bigger the 1.");
                    flag=true;
                }
            }
            String pat;
            flag=true;
            s.nextLine();
            System.out.println("Please give a binary pattern  for the coding(The pattern should has  1 in the first and the last position).");
            while(flag)
            {   
                flag=false;
                pat=s.nextLine();              
                int [] P1=new int[pat.length()];
                int i=0;
                if(pat.length()<2)
                    {
                        flag=true;
                        System.out.println("The pattern's size has to be bigger than 1 bit.");
                    }
                if(!flag)
                    if(pat.charAt(0)!='1'||pat.charAt(pat.length()-1)!='1')
                    {
                             flag=true;
                            System.out.println("The pattern should has 1 at the first and the last position.");
                        }
                int j;
                for(j=0;j<pat.length()&&!flag;j++)
                {
                    if(pat.charAt(j)=='1')
                    {P1[j]=1;
                    
                    }else if(pat.charAt(j)=='0'){
                        P1[j]=0;
                    }else{
                        flag=true;
                        System.out.println("Please give a binary pattern for coding(The pattern should has 1 int the first and the last position).");
                    }
                }
                P=P1;
            }
             
        }else
        {
            num=1000000;
            P[0]=1;P[1]=1;P[2]=0;P[3]=1;P[4]=0;P[5]=1;
            numOfBits=10;
            ber=1000;
        }
        //System.out.println("num= "+num+" "+"Pat= "+ Arrays.toString(P)+ "size= "+numOfBits);
        int allBits=numOfBits+P.length-1;
        if(a==1)
         System.out.println("Example with number of messages= "+num +", Pattern= "+ Arrays.toString(P)+", size of every message= "+numOfBits+ " bits and B.E.R= 1/"+ber);
        for(int i=0;i<num;i++)
        {
            mes=sender.sendMessage(allBits, P,ber);
            isCorrect=mes.getIsCorrect();
            findError=!receiver.getMessage(mes, P);
            if(!isCorrect)
            {
                messagesWithError++;
                if(findError)
                    messagesWithErrorWhoAreFound++;
                else{
                       messagesWithErrorWhoAreNOTFound++;}
            }
                
        }        
        System.out.println("Messages with error :    "+messagesWithError/(double)num*100+"% of all messages.");
        System.out.println("Messages with error which were found is :  "+(messagesWithErrorWhoAreFound/(double)messagesWithError)*100+"% of all messages with error.");
        System.out.println("Messages with error which were NOT found is : "+(messagesWithErrorWhoAreNOTFound/(double)messagesWithError)*100+"% of all messages with error.");
    }
    
}
